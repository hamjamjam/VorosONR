%% single file unpack
% USER MUST INPUT FILENAME BELOW

clear;
close all;
%% USER INPUT
filenames = 'Log19.txt';
herepath = pwd;
logpath = fullfile(pwd,'\Assets\logs');


%% PROFILE INPUT
whichProf = 12;
pad = 1; % set pad length (sec)
transition = 1; % set transition length (sec)

load('T.mat');
DATA = profileWriterFxn(T(whichProf,:), pad, transition);

%% Script
cd(logpath);
fid = fopen(filenames,'r');
txt = textscan(fid,'%s','delimiter','\n'); 
fclose(fid);
cd(herepath);
%flipped = 1; %flipped = 1 if controllers were in the wrong hands(!)
flipped = 0; %flipped = 0 if controllers were in CORRECT hands

if flipped == 1
    flip = -1;
else
    flip = 1;
end

currentLightState = 0;
currentPerceivedPosition = 0;

time = [];
angularVelocity = [];
rawChairPosition = [];
triggerTimes = [];
perceivedPositions = [];
lightChangeTimes = [0];
lightStates = [0];
chairPosition = [];
profStartTime = [];

adjust = 0;

for i=3:size(txt{1})
    line = txt{1}{i};
    if line(1) == "T"
        %record time
        mycell = split(line, ' ');
        tempTime = str2double(mycell{2});
        time = [time tempTime];

    elseif line(1) == "A"
        %record angular velocity
        mycell = split(line, '(');
        mycell2 = split(mycell{2}, ')');
        mycell3 = split(mycell2{1}, ', ');
        omega = str2double(mycell3);
        angularVelocity = [angularVelocity omega];

    elseif line(1) == "C"
        %record chair position
        mycell = split(line, ' ');

        if ~isempty(chairPosition)
            if (str2double(mycell{3}) - tempChairPosition) > 300
                adjust = adjust + 360;
            elseif (str2double(mycell{3}) - tempChairPosition) < -300
                adjust = adjust - 360;
            end
        end

        tempChairPosition = str2double(mycell{3});
        rawChairPosition = [rawChairPosition tempChairPosition];
        chairPosition = [chairPosition (tempChairPosition - adjust)];


    elseif line(1) == "R"
        %record right trigger press
        mycell = split(line, ' ');
        tempTime = str2double(mycell{3});

        currentPerceivedPosition = currentPerceivedPosition + 90*flip;
        perceivedPositions = [perceivedPositions currentPerceivedPosition];
        triggerTimes = [triggerTimes tempTime];

    elseif line(1:2) == "Le"
        %record left trigger press
        mycell = split(line, ' ');
        tempTime = str2double(mycell{3});

        currentPerceivedPosition = currentPerceivedPosition - 90*flip;
        perceivedPositions = [perceivedPositions currentPerceivedPosition];
        triggerTimes = [triggerTimes tempTime];

    elseif line(1:2) == "Li"
        %record change of lighting state
        mycell = split(line, ' ');
        
        % Kieran commented out for testing 6/7/21 -- now, lightState is
        % updated every timestep, so the 'change' isn't applicable anymore.
        %currentLightState = currentLightState*(-1)+1;
        lightChangeTimes = [lightChangeTimes tempTime];
        %lightStates = [lightStates currentLightState];
        
        % Kieran added 6/7/21
        lightStates = [lightStates str2num(mycell{2})];

    elseif line(1:2) == "St"
        % record times profiles are run
        mycell = split(line, ' ');
        profStartTime = [profStartTime str2num(mycell{2})];

    end
end

chairPosition = chairPosition - chairPosition(20);

inferredAngularVelocity = [];
inferredAngularVelocityTimes = [];

for i = 2:length(triggerTimes)
    tempInfferedAngularVelocity = (perceivedPositions(i) - perceivedPositions(i-1))/(triggerTimes(i) - triggerTimes(i-1));
    inferredAngularVelocity = [inferredAngularVelocity tempInfferedAngularVelocity*pi/180];
    tempInfferedAngularVecloityTimes = (triggerTimes(i) + triggerTimes(i-1))/2;
    inferredAngularVelocityTimes = [inferredAngularVelocityTimes tempInfferedAngularVecloityTimes];
end

inferredAngularVelocityTimes = triggerTimes(2:end);

lightChangeTimes(end+1) = time(end);
lightStates(end+1) = lightStates(end);

%%%%%%%%%%%%% plotting

%%plot of angular velocity information
figure();
tiledlayout(2,1)
nexttile

% Torin: Since angular velocity didn't record, we are computing it from the chair position.
% It is noisy, so I am smoothing it. I don't know why I need a factor of 2,
% but it sure seems the position perception is fairly accurate, but the
% angular velocity is offset by a factor of 2, so I threw that in for now.
% Going forward we won't use this, so its not worth trying to figure out! 
% plot(time, angularVelocity(2,:));
angVelfromPos = 2*pi/180 * smooth(diff(chairPosition)/(time(2)-time(1)), 300); % rad/s,  

plot(time(2:end), angVelfromPos);
hold on
scatter(inferredAngularVelocityTimes, inferredAngularVelocity);
legend('Angular Velocity','Inferred Perceived Angular Velocity');
title('True Angular Velocity and Inferred Angular Velocity');
xlabel('Time (s)');
ylabel('Angular velocity (rad/s)');

nexttile
stairs(lightChangeTimes,lightStates)
xlabel('Time (s)');
ylabel('Light Condition');
ylim([-1 2]);
title('Light Status');
yticks([0 1]);
yticklabels({'off','on'});

%%plot of position information
figure();
tiledlayout(2,1)
nexttile
plot(time, chairPosition);
hold on;
scatter(triggerTimes, perceivedPositions);

legend('Yaw Position','Perceived Yaw Position');
ylabel('Yaw position (degrees)');
xlabel('Time (s)');

nexttile
stairs(lightChangeTimes,lightStates)
xlabel('Time (s)');
ylabel('Light Condition');
ylim([-1 2]);
title('Light Status');
yticks([0 1]);
yticklabels({'off','on'});


%%plot experimentation light colour blocking

lightStatesPlot = (lightStates-1)*(-1);
ylimMin = min(chairPosition) - 200;
ylimMax = max(chairPosition) + 200;
bottom = ylimMin;
for i = 1:length(lightStatesPlot)
    if lightStatesPlot(i) == 0
        lightStatesPlot(i) = ylimMin;
    else
        lightStatesPlot(i) = ylimMax;
    end
end

figure();
sh = stairs(lightChangeTimes,lightStatesPlot);
x = [sh.XData(1),repelem(sh.XData(2:end),2)];
y = [repelem(sh.YData(1:end-1),2),sh.YData(end)];

% yaw position with light colourblock
fig1 = figure();
hold on;
fill([x,fliplr(x)],[y,bottom*ones(size(y))], [0.8,0.8,0.8],'LineStyle','none')
ylim([ylimMin ylimMax]);
plot(time, chairPosition, 'b');
% scatter(triggerTimes, perceivedPositions, 'r');
plot(triggerTimes, perceivedPositions, 'ro-');
plot([0 triggerTimes(1)-(triggerTimes(2)-triggerTimes(1)) triggerTimes(1)], [0 0 perceivedPositions(1)], 'r')
plot([triggerTimes(end) time(end)], [perceivedPositions(end) perceivedPositions(end)], 'r')

legend('Lights Off', 'Yaw Position','Perceived Yaw Position', 'Location', 'SouthWest');
ylabel('Yaw position (degrees)');
xlabel('Time (s)');
xlim([time(1) time(end)]);
saveas(fig1, ['position_' filenames(1:end-4) '.png']);

% angular velocity with light colourblock
lightStatesPlot = (lightStates-1)*(-1);
ylimMin = min(angularVelocity(2,:)) - 2;
ylimMax = max(angularVelocity(2,:)) + 2;
bottom = ylimMin;
for i = 1:length(lightStatesPlot)
    if lightStatesPlot(i) == 0
        lightStatesPlot(i) = ylimMin;
    else
        lightStatesPlot(i) = ylimMax;
    end
end

figure();
sh = stairs(lightChangeTimes,lightStatesPlot);
x = [sh.XData(1),repelem(sh.XData(2:end),2)];
y = [repelem(sh.YData(1:end-1),2),sh.YData(end)];

fig2 = figure();
hold on;
fill([x,fliplr(x)],180/pi * [y,bottom*ones(size(y))], [0.8,0.8,0.8],'LineStyle','none')
ylim(180/pi * [ylimMin ylimMax]);

% plot(time, angularVelocity(2,:), 'b');
plot(time(2:end), -180/pi * angVelfromPos, 'b'); 

% scatter(infferedAngularVecloityTimes, infferedAngularVelocity);
fudge = -1.5;
% fudge = -1;
plot(inferredAngularVelocityTimes, fudge * 180/pi * inferredAngularVelocity, 'ro-');
% This adds the assumed perception of 0 angular velocity until they press
% the button for the first time. Not the misspelling of Vecloity, but I
% didn't correct since its throughout! 
plot([0 inferredAngularVelocityTimes(1)-(inferredAngularVelocityTimes(2)-inferredAngularVelocityTimes(1)) inferredAngularVelocityTimes(1)], fudge * 180/pi * [0 0 inferredAngularVelocity(1)], 'r')
% And this does the back end towards 0 at the end of the trial
plot([inferredAngularVelocityTimes(end) inferredAngularVelocityTimes(end)+(inferredAngularVelocityTimes(end)-inferredAngularVelocityTimes(end-1)) time(end)], fudge * 180/pi * [inferredAngularVelocity(end) 0 0], 'r')

legend('Lights Off', 'Angular Velocity','Inferred Perceived Angular Velocity', 'Location', 'SouthWest');
ylabel('Angular velocity (deg/s)');
xlabel('Time (s)');
% xlim([time(1) time(end)]);
xlim([2.1 time(end)]);
saveas(fig2, ['angVel_' filenames(1:end-4) '.png']);

%% if a profile was run, plot the angular velocities

figure;
plot(time(2:end), -180/pi * angVelfromPos); hold on;
plot(time(2:end), -180/pi * angularVelocity(2,2:end));
if exist('profStartTime','var')
    plot((1:length(DATA))/90+profStartTime(1),DATA(:,1),'k');
end
legend({'from Position','from Headset','Commanded'});
xlabel('time [s]'); ylabel('Angular Velocity [deg/s]');
xlim([2.1 time(end)]);